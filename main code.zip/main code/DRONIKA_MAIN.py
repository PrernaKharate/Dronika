#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
from roboflow import Roboflow

# Initialize Roboflow Client
rf = Roboflow(api_key="DiIY0TeTANurWilrC3oi")
project = rf.workspace().project("gun-morwg")
roboflow_model = project.version(1).model

# Create a folder to store detected images
output_folder = "detected_images"
os.makedirs(output_folder, exist_ok=True)

# Function to perform object detection with Roboflow model
def perform_object_detection():
    # Open a file dialog for the user to select an image file
    file_path = filedialog.askopenfilename()

    # Check if a file was selected
    if file_path:
        # Perform object detection with Roboflow model
        predictions_json = roboflow_model.predict(file_path, confidence=40, overlap=30).json()
        print(predictions_json)  # Print predictions to the console

        # Create a folder to store detected images
        os.makedirs(output_folder, exist_ok=True)

        # Save the detected image from Roboflow to the folder
        original_image_name = os.path.splitext(os.path.basename(file_path))[0]  # Extract the filename without extension
        roboflow_detected_image_path = os.path.join(output_folder, f"{original_image_name}_roboflow_detected.jpg")
        roboflow_model.predict(file_path, confidence=40, overlap=30).save(roboflow_detected_image_path)
        
        

        # Display the original and detected images with titles
        display_window = tk.Toplevel(root)
        display_window.title("Images")

        # Display the original image with title
        original_image = Image.open(file_path)
        original_image.thumbnail((300, 300))
        original_image_tk = ImageTk.PhotoImage(original_image)
        original_label = tk.Label(display_window, text="Original Image")
        original_label.pack()
        original_label = tk.Label(display_window, image=original_image_tk)
        original_label.image = original_image_tk
        original_label.pack(side=tk.LEFT, padx=10)

        # Display the detected image from Roboflow with title
        roboflow_detected_image = Image.open(roboflow_detected_image_path)
        roboflow_detected_image.thumbnail((300, 300))
        roboflow_detected_image_tk = ImageTk.PhotoImage(roboflow_detected_image)
        roboflow_detected_label = tk.Label(display_window, text="Detected Image (Roboflow)")
        roboflow_detected_label.pack()
        roboflow_detected_label = tk.Label(display_window, image=roboflow_detected_image_tk)
        roboflow_detected_label.image = roboflow_detected_image_tk
        roboflow_detected_label.pack(side=tk.LEFT, padx=10)

        # Display a success message
        success_label.config(text=f"Detected image saved in the '{output_folder}' folder.")

# Create the main application window
root = tk.Tk()
root.title("Roboflow Object Detection GUI")
root.geometry("900x400")  # Adjust the window size as needed

# Label for instructions
instructions_label = tk.Label(root, text="Select an image file for object detection:")
instructions_label.pack(pady=10)

# Button to trigger object detection
detect_button = tk.Button(root, text="Choose Image", command=perform_object_detection, bg="lightblue")
detect_button.pack(pady=20)

# Label to display success message
success_label = tk.Label(root, text="")
success_label.pack(pady=10)

# Start the main event loop
root.mainloop()

