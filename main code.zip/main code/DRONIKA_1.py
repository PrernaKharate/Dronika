#!/usr/bin/env python
# coding: utf-8

# In[2]:


import tkinter as tk
from tkinter import filedialog
from ultralytics import YOLO
import cv2

# Create a function to perform object detection
def perform_object_detection():
    # Load the YOLO model
    model = YOLO("yolov8s.pt")
    
    # Open a file dialog for the user to select an image file
    file_path = filedialog.askopenfilename()
    
    # Check if a file was selected
    if file_path:
        # Perform object detection on the selected image
        results = model.predict(source=file_path, show=True, conf=0.4, save=True)

# Create the main application window
root = tk.Tk()
root.title("Object Detection GUI")

# Create a button to trigger object detection
# detect_button = tk.Button(root, text="Detect Objects", command=perform_object_detection)
# detect_button.pack(pady=20)

a = tk.Label(root, text="Upload any image:")
a.pack()

b1 = tk.Button(root, text="Choose File", command=perform_object_detection)
b1.pack()

lbl_image = tk.Label(root)
lbl_image.pack()


# Start the main event loop
root.mainloop()



# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[1]:





# In[ ]:





# In[ ]:




